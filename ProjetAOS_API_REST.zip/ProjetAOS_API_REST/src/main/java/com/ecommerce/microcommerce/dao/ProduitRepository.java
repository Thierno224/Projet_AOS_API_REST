package com.ecommerce.microcommerce.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.microcommerce.modele.Produit;

public interface ProduitRepository extends JpaRepository<Produit, Long>{
	
	public Produit findById(long id) ;

}
