package com.ecommerce.microcommerce.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.microcommerce.dao.ClientRepository;
import com.ecommerce.microcommerce.modele.Client;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value="api")
public class ClientController {
	
	@Autowired
	ClientRepository clientRepository ;
	
	@ApiOperation("Afficher la liste de tout les clients")
	@RequestMapping(value="/clients", method = RequestMethod.GET)
	public List<Client> getAllClient(){
		return clientRepository.findAll() ;
	}
	
	@ApiOperation("Unregistrer un client dans la base de données")
	@RequestMapping(value="/clients", method = RequestMethod.POST,
					produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Client> enregistrerUnClient(@RequestBody Client client){
		
		clientRepository.save(client) ;
		return new ResponseEntity<>(HttpStatus.CREATED) ;
	}
	
	@ApiOperation("Supprimer un a partir de son ID ")
	@RequestMapping(value="/clients/delete/{id}", method = RequestMethod.DELETE,
					produces = MediaType.APPLICATION_JSON_VALUE)
	
	public ResponseEntity<Client> supprimerUnClient(@PathVariable long id){
		Client client = clientRepository.findById(id) ;
		clientRepository.delete(client);
		
		return new ResponseEntity<>(HttpStatus.OK) ;
	}
	
	public ResponseEntity<Client> rechercheParId(@PathVariable long identifiant){
		return Optional.ofNullable(clientRepository.findById(identifiant))
				.map(client -> new ResponseEntity<>(
						client,
						HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NO_CONTENT)) ;
		
	}
	
	@ApiOperation("Mise a jour d'un client")
	@RequestMapping(value="/clients/update/{id}", method = RequestMethod.PUT,
			      produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Client> update(@RequestBody Client newClient, @PathVariable long id){
		
		Client client = clientRepository.findById(id) ;
		if(client != null) {
			
			client.setNom(newClient.getNom());
			client.setPrenom(newClient.getPrenom());
			client.setAdresse(newClient.getAdresse());
			client.setTelephone(newClient.getTelephone());
			client.setPhoto(newClient.getPhoto());
			clientRepository.save(client);
			return new ResponseEntity<>(HttpStatus.OK) ;
		}
		
		clientRepository.save(newClient) ;
		return new ResponseEntity<>(HttpStatus.CREATED) ;
	}

}
