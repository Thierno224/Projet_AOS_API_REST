package com.ecommerce.microcommerce.modele;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class CommandeClient implements Serializable{
 
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private long idCommande ;
	private String codeCommande ;
	private Date dateCommande ; 
	
	@OneToMany //(targetEntity =LigneCommandeClient.class, mappedBy="commandeClient", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<LigneCommandeClient> ligneCommandeClient ;
	
	@ManyToOne(cascade = {CascadeType.PERSIST},fetch= FetchType.EAGER)
	@JoinColumn(name ="id_client")
	@JsonBackReference
	private Client client ;
	
	public CommandeClient() {
		super();
	}

	public CommandeClient(String codeCommande, Date dateCommande, List<LigneCommandeClient> ligneCommandeClient,
			Client client) {
		super();
		this.codeCommande = codeCommande;
		this.dateCommande = dateCommande;
		this.ligneCommandeClient = ligneCommandeClient;
		this.client = client;
	}
	
	

	public CommandeClient(String codeCommande, Date dateCommande, List<LigneCommandeClient> ligneCommandeClient) {
		super();
		this.codeCommande = codeCommande;
		this.dateCommande = dateCommande;
		this.ligneCommandeClient = ligneCommandeClient;
	}

	public long getIdCommande() {
		return idCommande;
	}

	public void setIdCommandeClient(long idCommande) {
		this.idCommande = idCommande;
	}

	public String getCodeCommande() {
		return codeCommande;
	}

	public void setCodeCommande(String codeCommande) {
		this.codeCommande = codeCommande;
	}

	public Date getDateCommande() {
		return dateCommande;
	}

	public void setDateCommande(Date dateCommande) {
		this.dateCommande = dateCommande;
	}

	public List<LigneCommandeClient> getLigneCommandeClient() {
		return ligneCommandeClient;
	}

	public void setLigneCommandeClient(List<LigneCommandeClient> ligneCommandeClient) {
		this.ligneCommandeClient = ligneCommandeClient;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	@Override
	public String toString() {
		return "CommandeClient [idCommande=" + idCommande + ", codeCommande=" 
	            + codeCommande + ", dateCommande=" + dateCommande 
	            + ", ligneCommandeClient=" + ligneCommandeClient + ", client="+ client + "]";
	}
	
	
	

}
